package com.example.hostel_management

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.coroutines.tasks.await

class FirebaseHelper {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val database: DatabaseReference = FirebaseDatabase.getInstance().reference

    companion object {
        const val MAX_OCCUPANCY = 3  // Max students per room
    }

    // Get list of available rooms with occupancy count
    suspend fun getAvailableRooms(): List<RoomInfo> {
        return try {
            val roomsSnapshot = database.child("rooms").get().await()
            val availableRooms = mutableListOf<RoomInfo>()

            // Check rooms 1 to 100
            for (roomNum in 1..100) {
                val roomKey = "room_$roomNum"
                val occupancy = roomsSnapshot.child(roomKey).child("occupancy")
                    .getValue(Int::class.java) ?: 0

                if (occupancy < MAX_OCCUPANCY) {
                    availableRooms.add(RoomInfo("Room $roomNum", occupancy))
                }
            }

            availableRooms.sortedBy { it.occupancy } // Show emptiest rooms first
        } catch (e: Exception) {
            emptyList()
        }
    }

    // Sign Up User with Room Selection
    suspend fun signUpUser(
        email: String,
        password: String,
        regNumber: String,
        name: String,
        roomNumber: String  // User-selected room
    ): Result<String> {
        return try {
            // Check if room is still available
            if (roomNumber.isNotEmpty() && roomNumber != "Not Assigned") {
                val isAvailable = checkRoomAvailability(roomNumber)
                if (!isAvailable) {
                    return Result.failure(Exception("Room is now full. Please select another room."))
                }
            }

            // Create user account
            val authResult = auth.createUserWithEmailAndPassword(email, password).await()
            val userId = authResult.user?.uid ?: return Result.failure(Exception("User creation failed"))

            val userMap = hashMapOf(
                "regNumber" to regNumber,
                "name" to name,
                "email" to email,
                "roomNumber" to roomNumber.ifEmpty { "Not Assigned" }
            )

            database.child("users").child(userId).setValue(userMap).await()

            // Update room occupancy
            if (roomNumber.isNotEmpty() && roomNumber != "Not Assigned") {
                incrementRoomOccupancy(roomNumber, userId)
            }

            Result.success(userId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Check if room is available (has space)
    private suspend fun checkRoomAvailability(roomNumber: String): Boolean {
        return try {
            val roomKey = roomNumber.replace(" ", "_").lowercase()
            val snapshot = database.child("rooms").child(roomKey).get().await()
            val occupancy = snapshot.child("occupancy").getValue(Int::class.java) ?: 0
            occupancy < MAX_OCCUPANCY
        } catch (e: Exception) {
            false
        }
    }

    // Increment room occupancy
    private fun incrementRoomOccupancy(roomNumber: String, userId: String) {
        val roomKey = roomNumber.replace(" ", "_").lowercase()
        val roomRef = database.child("rooms").child(roomKey)

        roomRef.child("occupancy").get().addOnSuccessListener { snapshot ->
            val currentOccupancy = snapshot.getValue(Int::class.java) ?: 0
            roomRef.child("occupancy").setValue(currentOccupancy + 1)
            roomRef.child("members").child(userId).setValue(true)
        }
    }

    // Login User
    suspend fun loginUser(email: String, password: String): Result<String> {
        return try {
            val authResult = auth.signInWithEmailAndPassword(email, password).await()
            val userId = authResult.user?.uid ?: return Result.failure(Exception("Login failed"))
            Result.success(userId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Get User Details
    suspend fun getUserDetails(userId: String): UserDetails? {
        return try {
            val snapshot = database.child("users").child(userId).get().await()
            if (snapshot.exists()) {
                val regNumber = snapshot.child("regNumber").value.toString()
                val name = snapshot.child("name").value.toString()
                val roomNumber = snapshot.child("roomNumber").value.toString()
                UserDetails(regNumber, name, roomNumber)
            } else null
        } catch (e: Exception) {
            null
        }
    }

    // Submit Complaint
    suspend fun submitComplaint(
        regNumber: String,
        name: String,
        roomNumber: String,
        complaintText: String
    ): Result<String> {
        return try {
            val complaintId = database.child("complaints").push().key
                ?: return Result.failure(Exception("Failed to generate ID"))

            val complaintMap = hashMapOf(
                "complaintId" to complaintId,
                "regNumber" to regNumber,
                "name" to name,
                "roomNumber" to roomNumber,
                "complaintText" to complaintText,
                "timestamp" to ServerValue.TIMESTAMP,
                "status" to "Pending"
            )

            database.child("complaints").child(complaintId).setValue(complaintMap).await()

            Result.success(complaintId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getCurrentUserId(): String? = auth.currentUser?.uid

    fun logout() = auth.signOut()

    fun isUserLoggedIn(): Boolean = auth.currentUser != null
}

data class UserDetails(
    val regNumber: String,
    val name: String,
    val roomNumber: String
)

data class RoomInfo(
    val roomNumber: String,
    val occupancy: Int  // How many students currently in room
)
