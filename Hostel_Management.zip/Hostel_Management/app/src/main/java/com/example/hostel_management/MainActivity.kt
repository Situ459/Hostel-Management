package com.example.hostel_management

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat.startActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.lifecycleScope
import com.google.android.material.navigation.NavigationView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var toolbar: Toolbar
    private lateinit var tvUserNameToolbar: TextView
    private lateinit var tvRegNumber: TextView
    private lateinit var tvRoomNumber: TextView
    private lateinit var btnOverflowMenu: ImageView
    private lateinit var firebaseHelper: FirebaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        firebaseHelper = FirebaseHelper()

        // Check if user is logged in
        if (!firebaseHelper.isUserLoggedIn()) {
            navigateToLogin()
            return
        }

        initViews()
        setupToolbar()
        setupNavigationDrawer()
        setupCardClicks()
        setupOverflowMenu()
        loadUserData()
        setupBackPress()
    }

    private fun initViews() {
        drawerLayout = findViewById(R.id.drawerLayout)
        navigationView = findViewById(R.id.navigationView)
        toolbar = findViewById(R.id.toolbar)
        tvUserNameToolbar = findViewById(R.id.tvUserNameToolbar)
        tvRegNumber = findViewById(R.id.tvRegNumber)
        tvRoomNumber = findViewById(R.id.tvRoomNumber)
        btnOverflowMenu = findViewById(R.id.btnOverflowMenu)
    }

    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
    }

    private fun setupNavigationDrawer() {
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navigationView.setNavigationItemSelectedListener(this)

        // Update nav header with user name
        val headerView = navigationView.getHeaderView(0)
        val navHeaderName = headerView.findViewById<TextView>(R.id.navHeaderName)
        val btnViewProfile = headerView.findViewById<Button>(R.id.btnViewProfile)

        lifecycleScope.launch(Dispatchers.Main) {
            try {
                val userId = firebaseHelper.getCurrentUserId()
                if (userId != null) {
                    val userDetails = withContext(Dispatchers.IO) {
                        firebaseHelper.getUserDetails(userId)
                    }
                    if (userDetails != null) {
                        navHeaderName.text = userDetails.name
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Error loading profile: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        btnViewProfile.setOnClickListener {
            Toast.makeText(this, "Profile feature coming soon!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupCardClicks() {
        findViewById<CardView>(R.id.cardNoticeBoard).setOnClickListener {
            Toast.makeText(this, "Notice Board feature coming soon!", Toast.LENGTH_SHORT).show()
        }

        findViewById<CardView>(R.id.cardUpcomingEvents).setOnClickListener {
            Toast.makeText(this, "Upcoming Events feature coming soon!", Toast.LENGTH_SHORT).show()
        }

        findViewById<CardView>(R.id.cardNewsUpdates).setOnClickListener {
            Toast.makeText(this, "News & Updates feature coming soon!", Toast.LENGTH_SHORT).show()
        }

        findViewById<CardView>(R.id.cardSubmitComplaint).setOnClickListener {
            Toast.makeText(this, "Submit Complaint feature coming soon!", Toast.LENGTH_SHORT).show()
        }

        findViewById<CardView>(R.id.cardMyComplaints).setOnClickListener {
            Toast.makeText(this, "My Complaints feature coming soon!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupOverflowMenu() {
        btnOverflowMenu.setOnClickListener { view ->
            val popupMenu = PopupMenu(this, view)
            popupMenu.menuInflater.inflate(R.menu.overflow_menu, popupMenu.menu)
            popupMenu.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.menu_room_details -> {
                        Toast.makeText(this, "Room Details coming soon!", Toast.LENGTH_SHORT).show()
                        true
                    }
                    R.id.menu_fees -> {
                        Toast.makeText(this, "Fees coming soon!", Toast.LENGTH_SHORT).show()
                        true
                    }
                    R.id.menu_mess_menu -> {
                        Toast.makeText(this, "Mess Menu coming soon!", Toast.LENGTH_SHORT).show()
                        true
                    }
                    R.id.menu_complaint -> {
                        Toast.makeText(this, "Submit Complaint coming soon!", Toast.LENGTH_SHORT).show()
                        true
                    }
                    else -> false
                }
            }
            popupMenu.show()
        }
    }

    private fun loadUserData() {
        val userId = firebaseHelper.getCurrentUserId()

        if (userId == null) {
            navigateToLogin()
            return
        }

        lifecycleScope.launch(Dispatchers.Main) {
            try {
                val userDetails = withContext(Dispatchers.IO) {
                    firebaseHelper.getUserDetails(userId)
                }

                if (userDetails != null) {
                    tvUserNameToolbar.text = "Welcome, ${userDetails.name}"
                    tvRegNumber.text = userDetails.regNumber
                    tvRoomNumber.text = userDetails.roomNumber
                } else {
                    Toast.makeText(this@MainActivity, "Failed to load user data", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupBackPress() {
        onBackPressedDispatcher.addCallback(this) {
            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.closeDrawer(GravityCompat.START)
            } else {
                finish()
            }
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_settings -> {
                Toast.makeText(this, "Settings coming soon!", Toast.LENGTH_SHORT).show()
            }
            R.id.nav_help -> {
                Toast.makeText(this, "Help & Support coming soon!", Toast.LENGTH_SHORT).show()
            }
            R.id.nav_about -> {
                Toast.makeText(this, "About coming soon!", Toast.LENGTH_SHORT).show()
            }
            R.id.nav_logout -> {
                firebaseHelper.logout()
                Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show()
                navigateToLogin()
            }
        }
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun navigateToLogin() {
            startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
